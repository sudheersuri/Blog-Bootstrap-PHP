<?php
$conn=new mysqli("localhost","root","","test");
if(!$conn)
die("Connection error");
?>
