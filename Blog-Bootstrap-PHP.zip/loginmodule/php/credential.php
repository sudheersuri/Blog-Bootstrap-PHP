<?php 
	/*Update credentials*/
	define('EMAIL', 'admin@hudyshoe.com');
	define('PASS', 'HudyShoe@SMTP2233');
 ?>